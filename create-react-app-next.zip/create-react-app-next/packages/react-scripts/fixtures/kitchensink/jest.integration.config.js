module.exports = {
  testEnvironment: 'node',
  testMatch: ['**/integration/*.test.js'],
};
